int1=int(input('정수를 입력하세요: '))
i=0
sum=0

while i<int1:
    i+=3
    sum+=i

print('0 부터',int1,'까지 3의 배수 합은',sum,'입니다')