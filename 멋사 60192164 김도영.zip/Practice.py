a=str(input("당신의 이름은?"))

print("안녕 ,"+a+"!")

