"김멋사의 나이는 20살입니다!"
profile={'이름':'김멋사'}
key=input('key값을 입력해주세요: ')
value= input('value값을 입력해주세요: ')
profile[key]=value
print(profile)
#60192164 김도영